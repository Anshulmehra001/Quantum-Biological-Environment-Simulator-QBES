"""
Test suite for QBES.
"""